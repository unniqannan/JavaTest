/**
 * 
 */
package com.gurukula.common;

/**
 * @author AnujKumar
 *
 */
public enum ActionsEnum {

	View, Edit, Delete, Save, Cancel, Create
}
