/**
 * 
 */
package com.gurukula.common;

/**
 * @author AnujKumar
 *
 */
public enum EntitiesEnum {

	Branch, Staff
}
