/**
 * 
 */
package com.gurukula.common;

/**
 * @author AnujKumar
 *
 */
public enum MenuEnum {

	Home, Entities, Account
}
