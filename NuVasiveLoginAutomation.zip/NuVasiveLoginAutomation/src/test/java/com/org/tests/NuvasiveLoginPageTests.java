
package com.org.tests;

import org.apache.log4j.Logger;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.org.pages.NuvasiveLoginPage;
import com.org.utility.StartApplication;


public class NuvasiveLoginPageTests extends StartApplication {

	public static Logger logger = Logger.getLogger(NuvasiveLoginPageTests.class.getName());

	 
	NuvasiveLoginPage NuvasiveLoginPage;
	
	@Test
	public void tc_01_LoginPageAvailable() {
		preSteps();
		NuvasiveLoginPage.NuvasiveLoginPageMainPageHeaderCheck();
		
	}
	
	//@Test(dataProvider = "CurrencyInput")
	public void tc_01_currencyConversionValidation(String sourceCountryCurrency, String targetCountryCurrency,String ConvertedToCurrencyResults) {
		preSteps();
		NuvasiveLoginPage.NuvasiveLoginPageMainPageHeaderCheck();
	}

	private void preSteps() {
		NuvasiveLoginPage = new NuvasiveLoginPage(driver);
	}

	@DataProvider(name = "CurrencyInput")
	public Object[][] CurrencySelection() {
		return new Object[][] {
			// @formatter:off
			{ "EUR", "USD","1.09820 USD" }
			//,
			//{ "INR", "USD","0.01412 USD" }, 
			//{ "GBP", "INR","87.50680 INR" },
			//{ "CAD", "MXN","14.66340 MXN" },
			//{ "AUD", "NZD","1.07160 NZD" } 
			// @formatter:on
		};
	}

}
