package com.org.enums;

/*
 * Menu items which user might click to navigate to the pages
 * */

public enum AppMenuEnum {

	Home, Entities, Account
}
