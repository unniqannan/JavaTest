
package com.org.enums;

/*These are the actions user would be doing 
 * on the application*/

public enum AppUserActionsEnum {

	View, Edit, Delete, Save, Cancel, Create
}
