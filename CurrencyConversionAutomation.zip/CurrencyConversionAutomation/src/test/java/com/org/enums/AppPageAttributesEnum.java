
package com.org.enums;

/*
 * These are main entities of the application which user might 
 * use to create objects
 * */

public enum AppPageAttributesEnum {

	Branch, Staff
}
